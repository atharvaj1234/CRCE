#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

struct Node {
    char songName[100];
    struct Node *next;
    struct Node *prev;
};

struct Node *head = NULL;
struct Node *current = NULL;

// Function to create a new node
struct Node* createNode(char *song) {
    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
    strcpy(newNode->songName, song);
    newNode->next = newNode->prev = newNode; 
    return newNode;
}

// Function to insert a song
void insertSong(char *song) {
    struct Node *newNode = createNode(song);
    if (head == NULL) {
        head = newNode;
        current = head;
    } else {
        struct Node *last = head->prev;
        last->next = newNode;
        newNode->prev = last;
        newNode->next = head;
        head->prev = newNode;
    }
}

// Function to play current song
void playSong() {
    if (current == NULL) {
        printf("No songs in the playlist.\n");
        return;
    }
    printf("Now Playing: %s\n", current->songName);
    char command[200];
    sprintf(command, "start %s", current->songName);
    system(command);
}

// Function to stop current song
void stopSong() {
    printf("Stopping song...\n");
    
    system("taskkill /IM Musics.exe /F >nul 2>&1");
    system("taskkill /IM mediaplayer.exe /F >nul 2>&1");
    system("taskkill /IM Microsoft.Media.Player.exe /F >nul 2>&1"); 
    system("taskkill /IM wmplayer.exe /F >nul 2>&1"); 
    
    
    printf("Stop command sent.\n");
}

// Move to next song
void nextSong() {
    if (current == NULL) {
        printf("No songs available.\n");
        return;
    }
    stopSong();
    current = current->next;
    playSong();
}

// Move to previous song
void prevSong() {
    if (current == NULL) {
        printf("No songs available.\n");
        return;
    }
    stopSong();
    current = current->prev;
    playSong();
}

int main() {
    int choice;
    char song[100];

    // Add songs to playlist 
    insertSong("Perfect.mp3");
    insertSong("Rewrite_The_Stars.mp3");
    insertSong("I_Wanna_Be_Yours.mp3");

    while (1) {
        printf("\n=== Circular Linked List Music Player ===\n");
        printf("1. Play Current Song\n");
        printf("2. Stop Song\n");
        printf("3. Next Song\n");
        printf("4. Previous Song\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar();

        switch (choice) {
            case 1:
                playSong();
                break;
            case 2:
                stopSong();
                break;
            case 3:
                nextSong();
                break;
            case 4:
                prevSong();
                break;
            case 5:
                printf("Exiting player.\n");
                stopSong();
                return 0;
            default:
                printf("Invalid choice! Try again.\n");
        }
    }

    return 0;
}
